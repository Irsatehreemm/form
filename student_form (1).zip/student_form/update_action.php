<?php
include('connection.php');

if(isset($_POST['update']))
{
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $fathername=$_POST['fathername'];
    $email=$_POST['email'];
    
    $date_of_birth=$_POST['date_of_birth'];
    $gender=$_POST['gender'];
    
     $subject=$_POST['subject'];
     $department=$_POST['department'];

     if (@$_FILES['image']['name']) {
        $temp = explode('.', $_FILES['image']['name']);
        $extension = end($temp);
        $path = './asset/images/';
        $filename = basename($_FILES['image']['name']); 
        $filename = time() . "." . $extension;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $path . $filename)) {
            $image=$filename;
        } else {
             $image=$_POST['previous_image'];
        }
    }else{
    $image=$_POST['previous_image'];
    }
    //image code end
    
    
    

 $id = $_POST['id'];
    
     

    $query= mysqli_query($connection,"UPDATE student SET firstname='$firstname' , lastname='$lastname' ,fathername='$fathername', email='$email',date_of_birth='$date_of_birth',gender='$gender',subject='$subject',department='$department',image='$image' WHERE id=$id");


    
    if($query){
      header('Location: fetch.php');  //php location
    }
    else {
        echo "error";
    }
}


?>