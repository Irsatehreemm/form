<?php
include('connection.php');
$id=$_GET['ID'];
$query=mysqli_query($connection,"DELETE FROM student WHERE id=$id");
if($query){
    header('Location: fetch.php');
   // echo "Record deleted successfully";
 }
 else
 {
    echo "Error";
 }

?>