<?php
include('connection.php');

$id = $_GET['ID'];
$query = mysqli_query($connection,"SELECT * FROM student WHERE id=$id");
$data = mysqli_fetch_array($query);
 //echo "<pre>";print_r($data);die();

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>std_reg_form</title>
  </head>
  <body>
    <!-- nav tag -->
    <nav class="navbar navbar-light bg-success  justify-content-center text-light">
       <h4>update your data</h4>
    </nav>
    <div class="container mb-4 mt-3">
        <div id="red">
           <h4> Enter your data</h4>
        </div>
    <form action="update_action.php" method="POST" enctype="multipart/form-data">
  <div class="mb-3 mt-4">
    <label >firstname :</label>
    <input type="text"  value="<?php echo $data['firstname']?>" id="firstnsme" name="firstname">  
    <label >lastname :</label>
    <input type="text"value="<?php echo $data['lastname']?>" id="lastname" name="lastname">
  </div><br>
    

  
  <div class="mb-3">
    <label >fathername :</label>
    <input type="text"value="<?php echo $data['fathername']?>" id="fathername" name="fathername">
  </div><br>
  <div class="mb-3">
    <label >email :</label>
    <input type="email"  value="<?php echo $data['email']?>"id="email" name="email">
  </div>
  <div class="mb-3">
  <label >date_of_birth :</label>
    <input type="date"  value="<?php echo $data['date_of_birth']?>"id="date_of_birth" name="date_of_birth"><br><br>
    </div>
    <div class="mb-3">
  
  <label>gender :<label>
    <select name="gender">
      <option value="">chose</option>
      <option value="male"<?php if($data['gender']=='male'){ echo "selected";} ?> >male</option>
      <option value="female"<?php if($data['gender']=='female'){ echo "selected";} ?> >female</option>
       </select>
       
    
     </div>



     



     <div class="mb-3">
<label>subject :</label><br>
     math :<input type="checkbox" value="math" <?php if($data['subject']=='math'){ echo "checked";}?> name="subject"><br>
     physic :<input type="checkbox" value="phy" <?php if($data['subject']=='phy'){ echo "checked";}?> name="subject"><br>
     eng :<input type="checkbox" value="eng"<?php if($data['subject']=='eng'){ echo "checked";}?> name="subject"><br>
     urdu :<input type="checkbox" value="urdu"<?php if($data['subject']=='urdu'){ echo "checked";}?> name="subject"><br>
     computer :<input type="checkbox" value="computer" <?php if($data['subject']=='computer'){ echo "checked";}?> name="subject"><br>

</div><br>

<div class="mb-3">
  <label>department</label>
 DSNT : <input type="radio" value="DSNT"<?php if($data['department']=='DSNT'){ echo "checked";}?> name="department" id="department"><br>
   BSIT :<input type="radio" value="BSIT" <?php if($data['department']=='DSNT'){ echo "checked";}?> name="department" id="department"><br>
  MA_ENGLISH :<input type="radio" value="MA_ENGLISH"<?php if($data['department']=='DSNT'){ echo "checked";}?> name="department" id="department"><br>
  BSCS :<input type="radio" value="BSCS" <?php if($data['department']=='DSNT'){ echo "checked";}?> name="department" id="department"><br>
  </div>

 
  <label > profile :</label>
     <input type="file" name="image"> <br><br>
<input type="hidden" value="<?php echo $data['image'] ?>"  name="previous_image">
 
<input type="hidden" value="<?php echo $data['id'] ?>"  name="id">
  
  <button type="submit" class="btn btn-primary" name="update">update</button><br>
</form>
    </div>
    
    


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>