<?php 
$servername="localhost";
$username="root";
$password="";
$db="education";
$connection=mysqli_connect($servername,$username,$password,$db);
if($connection){
  // echo "connection successfully";
 
}
else{
    echo "error";
}
?>