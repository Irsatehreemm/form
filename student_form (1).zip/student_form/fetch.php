
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title> std_reg_form</title>
  </head>
  <body>
  <table class="table">
  <thead>
    <tr>
      <th>id#</th>
      <th>Firstname</th>
      <th>Lastname</th>
      <th>fathername</th>
      <th>mail</th>
      <th>date_of_birth</th>
      <th>gender</th>
      
      <th>subject</th>
      <th>department</th>
      <th>image</th>
      
      <th>action</th>
    </tr>
  </thead>
  <body>
  <?php
  include('connection.php');
  $i=0;
  $query=mysqli_query($connection,"SELECT * FROM student");
   while($data=mysqli_fetch_array($query)){
     $i++;
?>
 <tr>
 <td><?php echo $i?></td>
    <td><?php echo $data['firstname'] ?></td>
    <td><?php echo $data['lastname'] ?></td>
    <td><?php echo $data['fathername'] ?></td>
    <td><?php echo $data['email'] ?></td>
    <td><?php echo $data['date_of_birth'] ?></td>
    <td><?php echo $data['gender'] ?></td>
    
    <td><?php echo $data['subject'] ?></td>
    <td><?php echo $data['department'] ?></td>
    <td>
        <img src="asset/images/<?php echo $data['image'] ?>" height="80" width="80">
    </td>
    
    <td>
      <button  class='btn btn-danger '><a  href='delete.php?ID=<?php echo $data['id']?>'  class="text-light"> delete</a></button>
    <button  class='btn btn-primary '><a href='update.php?ID=<?php echo $data['id']?>' class="text-light"> update</a>
</button>
    
       
</td>

 </tr>
  
  <?php } ?>
 </body>
</table>

   
  </body>
</html>
<!--  -->
<!-- <button class='btn btn-primary'>  <a href='update.php?id=$row[sno] &title=$row[title] &desc=$row[description]'  class='text-light'>update</a></button> -->
        <!-- <button class='btn btn-danger'>  <a href='delete.php?id=$row[sno]' class='text-light' >delete</a></button> -->
    <!-- </td> -->
<!--  -->