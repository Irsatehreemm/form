<?php
include('connection.php');

if(isset($_POST['save']))
{

   $firstname = $_POST['firstname'];
   $lastname = $_POST['lastname'];
   $fathername = $_POST['fathername'];
   $email = $_POST['email'];
   $date_of_birth = $_POST['date_of_birth'];
   $gender=$_POST['gender'];
    $subject=$_POST['subject'];
   $department=$_POST['department'];
//image code start
//image code start
if (@$_FILES['image']['name']) {
   $temp = explode('.', $_FILES['image']['name']);
   $extension = end($temp);
   $path = './asset/images/';
   $filename = basename($_FILES['image']['name']); 
   $filename = time() . "." . $extension;
   if (move_uploaded_file($_FILES['image']['tmp_name'], $path . $filename)) {
       $image=$filename;
   } else {
        $image='user.png';
   }
}else{
$image='user.png';
}
//image code end
   

   $query = mysqli_query($connection,"insert into student (firstname ,lastname,fathername,email,date_of_birth,gender,subject,department,image)values('$firstname','$lastname','$fathername','$email','$date_of_birth','$gender','$subject','$department','$image')");
   if($query)
   {   
      header('Location: fetch.php');  //php location
      //echo "Record inserted successfully";
   }
   else
   {
    echo "Error";
   }


}

?>